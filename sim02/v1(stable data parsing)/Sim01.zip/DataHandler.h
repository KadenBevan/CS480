#ifndef DATAHANDLER_H
#define DATAHANDLER_H

#include <stdlib.h>
#include <string.h>
#include "structures.h"
#include "linkedlist.h"
#include "utility.h"

// ERRORS


//functions
int convert_data(LinkedList* meta_list);



#endif