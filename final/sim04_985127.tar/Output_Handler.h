#ifndef OUTPUT_HANDLER_H
#define OUTPUT_HANDLER_H

#include <stdio.h>
#include <stdlib.h>
#include "Structures.h"
#include "Utility.h"

void handle_output(Config *config, OutputNode *output);

#endif